package tp_enum.dao;


import java.util.List;

import socle.exception.TechniqueException;
import tp_interfaces.domaine.Note;

public interface INoteDao {

	int initBDD() throws TechniqueException;

	void enregistrerNote(Note n) throws TechniqueException;

	List<Note> getListeComplete() throws TechniqueException;

	void close() throws TechniqueException;

}