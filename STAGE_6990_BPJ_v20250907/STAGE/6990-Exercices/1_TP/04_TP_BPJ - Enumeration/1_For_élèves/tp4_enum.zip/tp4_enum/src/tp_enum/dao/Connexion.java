package tp_enum.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import socle.exception.TechniqueException;

public class Connexion {
	private static Connection maConnection;
	private final static String URL = "jdbc:hsqldb:mem:dbpersonnes";
	private final static String DRIVER = "org.hsqldb.jdbcDriver";

	// dans la vraie vie cette calsse serait un singleton, ici une version plus
	// simple via des methodes statiques

	public static Connection getConnexion() throws TechniqueException {
		// dans cette version on ne propage l'exception, on se contente
		// d'afficher la trace en cas d'erreur
		if (maConnection != null)
			return maConnection;
		try {
			// sollicitation du driver Hsql
			Class.forName(DRIVER);
			// obtention d'une connection
			maConnection = DriverManager.getConnection(URL);
		} catch (ClassNotFoundException e) {
			throw new TechniqueException("Problème pour trouver la classe : " + URL, e);
		} catch (SQLException e) {
			throw new TechniqueException("Problème lors de l'ouverture de la connexion : " + URL, e);
		}
		return maConnection;
	}

	public static void close() throws TechniqueException {
		try {
			if (maConnection != null) {
				maConnection.close();
				maConnection = null;
			}
		} catch (SQLException e) {
			throw new TechniqueException("Problème lors du close()", e);
		}
	}
}
