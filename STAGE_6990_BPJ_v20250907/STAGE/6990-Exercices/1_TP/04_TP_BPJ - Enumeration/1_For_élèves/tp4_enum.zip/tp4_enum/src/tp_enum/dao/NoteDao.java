package tp_enum.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import socle.exception.TechniqueException;
import tp_interfaces.domaine.Note;

public class NoteDao implements INoteDao {
	@Override
	public int initBDD() throws TechniqueException {
		// chargement Driver
		String sql = "create table NOTE (MATIERE char(30), NOTE INTEGER, COEFFICIENT INTEGER );";
		// ,age integer
		Connection c = Connexion.getConnexion();
		try (PreparedStatement ps = c.prepareStatement(sql)) {
			int retour = ps.executeUpdate();
			if (retour == 0) {
				return 0;
			}
		} 
		catch (SQLException e) {
			throw new TechniqueException("Problème avec : " + sql, e);
		}

		return -1;
	}

	@Override
	public void enregistrerNote(Note n) throws TechniqueException {
		Connection c = Connexion.getConnexion();
		// creation en BDD d'une nouvelle note
		String sql = "insert into NOTE (MATIERE,NOTE,COEFFICIENT) values (?,?,?)";
		try (PreparedStatement ps = c.prepareStatement(sql)) {
			ps.setString(1, n.getMatiere());
			ps.setInt(2, n.getNote());
			ps.setInt(3, n.getCoefficient());
			ps.executeUpdate();
		} 
		catch (SQLException e) {
			throw new TechniqueException("Problème avec : " + sql, e);
		}
	}
	
	@Override
	public List<Note> getListeComplete() throws TechniqueException {
		List<Note> listePersonnesRetour = new ArrayList<Note>();
//		Statement s = null;
//		ResultSet r = null;
		Connection c = Connexion.getConnexion();
		// creation de la requete
		String sql = "select MATIERE,NOTE,COEFFICIENT from NOTE";
		try (Statement s = c.createStatement() ; ResultSet r = s.executeQuery(sql)) {
//			s = c.createStatement();
//			r = s.executeQuery(sql);
			while (r.next()) {
				Note p = new Note(r.getString("MATIERE"), r.getInt("NOTE"),
						r.getInt("COEFFICIENT"));
				listePersonnesRetour.add(p);
			}
		} 
		catch (SQLException e) {
			throw new TechniqueException("Problème avec : " + sql, e);
		}
		return listePersonnesRetour;
	}

	@Override
	public void close() throws TechniqueException {
		Connexion.close();
	}


}
