package tp_interface.socle.exception;

public class TechniqueException extends Exception {
	private static final long serialVersionUID = 1L;

	public TechniqueException(String message, Throwable cause) {
		super(message, cause);
	}

	
}
