package tp_interface.service;

import java.util.List;

import tp_interface.dao.NoteDao;
import tp_interface.domaine.Note;
import tp_interface.socle.exception.TechniqueException;

public class NoteService {
	private NoteDao noteDao = new NoteDao();
	
	public int initBDD() throws TechniqueException {
		return noteDao.initBDD();
	}

	public void enregistrerNote(Note n) throws TechniqueException {
		noteDao.enregistrerNote(n);
	}

	public List<Note> getListeComplete() throws TechniqueException {
		return noteDao.getListeComplete();
	}

	public void close() throws TechniqueException {
		noteDao.close();
	}

}
